resource.AddFile( "sound/weapons/nofuckoff01.wav" )
resource.AddFile( "sound/weapons/nofuckoff02.wav" )
resource.AddFile( "materials/weapons/nfoicon.vmt" )
resource.AddFile( "materials/weapons/nfoicon.vtf" )

SWEP.Author = "RandomPerson189"
SWEP.Contact = "steamcommunity.com/id/684573485734857348573457938"
SWEP.Purpose = ""
SWEP.Instructions = "Left Click: Say no fuck off (The target you're looking at will disintegrate)"

SWEP.Spawnable = true 
SWEP.AdminSpawnable = true 

SWEP.ViewModel = "" 
SWEP.WorldModel = ""

SWEP.Primary.ClipSize = -1 
SWEP.Primary.DefaultClip = -1 
SWEP.Primary.Automatic = false 
SWEP.Primary.Ammo = "none"

SWEP.Secondary.ClipSize = -1  
SWEP.Secondary.DefaultClip = -1    
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = "none" 

SWEP.DrawAmmo = false

SWEP.HoldType = "normal"

if CLIENT then
	SWEP.PrintName = "No Fuck Off SWEP"
	SWEP.Slot = 1
	SWEP.SlotPos = 1
	SWEP.DrawAmmo = false
	SWEP.DrawCrosshair = true
	SWEP.WepSelectIcon = surface.GetTextureID("weapons/nfoicon")
	
	killicon.Add( "weapon_nofuckoff", "weapons/nfoicon", Color(255, 255, 255) )
end

local NoFuckOffSound = Sound ("weapons/nofuckoff01.wav")
local BoomSound = Sound ("weapons/nofuckoff02.wav")

function SWEP:Initialize()
	util.PrecacheSound( "weapons/nofuckoff01.wav" )
	util.PrecacheSound( "weapons/nofuckoff02.wav" )
	
	self:SetHoldType(self.HoldType)
end

function SWEP:Deploy()
	self.Weapon:SetNoDraw( true )
end 

function SWEP:Reload() 
end 

function SWEP:Think() 
end 

function SWEP:SecondaryAttack()
end

function SWEP:PrimaryAttack()
    self.Weapon:EmitSound (NoFuckOffSound, 350)
	self.Weapon:SetNextPrimaryFire( CurTime() + 1.3 )
	
	if CLIENT then return end
	
	self.Owner:PlayScene("scenes/nofuckoff.vcd")
	
	local trace = self.Owner:GetEyeTrace()
	local target = nil
	
	if trace.Entity:IsPlayer() or trace.Entity:IsNPC() or trace.Entity:IsNextBot() then
		if !trace.Entity:IsWorld() and !trace.Entity:GetClass() != "worldspawn" then
			target = trace.Entity
		end
	end
	
 	timer.Simple(1.01, function()
	if !IsValid(self) then return end
		local trace2 = self.Owner:GetEyeTrace()
		
		if trace2.Entity:IsPlayer() or trace2.Entity:IsNPC() or trace2.Entity:IsNextBot() then
			target = trace2.Entity
		end
		
		if IsValid(target) then
			local damage = DamageInfo()
			damage:SetDamage( math.huge )
			damage:SetAttacker( self.Owner )
			damage:SetDamageType( DMG_DISSOLVE )
			damage:SetDamageForce( Vector(0, 1, 0) )
			
			target:TakeDamageInfo( damage )
			
			local dissolver = ents.Create("env_entity_dissolver")
			dissolver:SetKeyValue("dissolvetype", 4)
			dissolver:SetKeyValue("magnitude", 0)
			dissolver:SetPhysicsAttacker(self.Owner)
			dissolver:SetPos(Vector(0, 0, 0))
			dissolver:Spawn()
			
			if target:IsPlayer() then
				dissolver:Fire("Dissolve", target:AccountID())
				dissolver:Fire("Kill", "", 0)
			else
				target:SetName("TARGET_NOFUCKOFF")
				
				dissolver:Fire("Dissolve", target:GetName())
				dissolver:Fire("Kill", "", 0)
			end
			
			target:EmitSound(BoomSound, 400)
		end
	end )
end